﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cashapp
{
    public partial class Form1 : Form
    {
        Shop shop1;
        Order order;
        public Form1()
        {
            InitializeComponent();
            shop1 = new Shop(1);
            List<Product> prods = shop1.GetAllProducts();
            order = new Order();
            
        }
        //updates listbox, total cost of order 
        private void Update() 
        {
            orderlist.Items.Clear();
            try
            {
                double total = 0;
                foreach (var i in order.productlist)
                {
                    if (i.Quantity > 0)
                    {
                        orderlist.Items.Add(i.ToString() + " - Quantity: " + i.Quantity);
                        total += i.PricePerOne * i.Quantity;
                    }
                    
                }

                //update label total
                lblTotal.Text = total.ToString() + "€";
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("Please select an item from your order");
            }
            
        }
        //adds one to quantity
        private void AddOne()
        {
            try
            {
                int index = orderlist.SelectedIndex;
                order.productlist[index].Quantity += 1;
            }
            catch 
            {
                MessageBox.Show("Please select an item from your order");
            }
            
        }
        //removes one from quantity
        private void RemoveOne()
        {
            try
            {
                int index = orderlist.SelectedIndex;
                order.productlist[index].Quantity -= 1;

                if (order.productlist[index].Quantity == 0)
                    order.productlist.RemoveAt(index);
            }
            catch
            {
                MessageBox.Show("Please select an item from your order");
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Sprite");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void btnCola_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("CocaCola");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void btnCalcPlus_Click(object sender, EventArgs e)
        {
            try
            {
                AddOne();
                Update();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnCalcMinus_Click(object sender, EventArgs e)
        {
            try
            {
                RemoveOne();
                Update();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnFanta_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Fanta");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void btnSchweppes_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Schweppes");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void btnRedBull_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("RedBull");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Bavaria");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Jupiler");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Heineken");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Corona");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Kameniza");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("OrangeJuice");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void btnSmirnoff_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Smirnoff");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("JackDaniels");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("HavanaClub");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Tequila");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Pizza");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Doner");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Fries");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Sandwich");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("HotDog");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Product p = shop1.GetProduct("Nuts");
            p.Quantity += 1;

            //add product to temporary order list
            order.AddProduct(p);
            Update();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            Checkout form = new Checkout();
            form.Show();
            
        }
    }
}
