﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cashapp
{
    public class Order
    {
        public int OrderID { get; set; }
        public List<Product> productlist { get; set; }

        public Order()
        {
            OrderID++;
            productlist = new List<Product>();
        }

        public void AddProduct(Product p)
        {
            productlist.Add(p);
        }
    }
}
