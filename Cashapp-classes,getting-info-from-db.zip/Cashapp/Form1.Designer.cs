﻿namespace Cashapp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.orderlist = new System.Windows.Forms.ListBox();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnCola = new System.Windows.Forms.Button();
            this.btnSprite = new System.Windows.Forms.Button();
            this.btnSchweppes = new System.Windows.Forms.Button();
            this.btnRedBull = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.btnSmirnoff = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.btnCalcMinus = new System.Windows.Forms.Button();
            this.btnCalcPlus = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.btnFanta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // orderlist
            // 
            this.orderlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderlist.FormattingEnabled = true;
            this.orderlist.ItemHeight = 20;
            this.orderlist.Location = new System.Drawing.Point(812, 12);
            this.orderlist.Name = "orderlist";
            this.orderlist.Size = new System.Drawing.Size(309, 484);
            this.orderlist.TabIndex = 0;
            // 
            // btnCheckout
            // 
            this.btnCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckout.Location = new System.Drawing.Point(812, 502);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(309, 69);
            this.btnCheckout.TabIndex = 1;
            this.btnCheckout.Text = "Checkout";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(567, 532);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 38);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(671, 532);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(64, 39);
            this.lblTotal.TabIndex = 3;
            this.lblTotal.Text = "0 €";
            // 
            // btnCola
            // 
            this.btnCola.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCola.BackgroundImage")));
            this.btnCola.Location = new System.Drawing.Point(12, 12);
            this.btnCola.Name = "btnCola";
            this.btnCola.Size = new System.Drawing.Size(154, 107);
            this.btnCola.TabIndex = 4;
            this.btnCola.UseVisualStyleBackColor = true;
            this.btnCola.Click += new System.EventHandler(this.btnCola_Click);
            // 
            // btnSprite
            // 
            this.btnSprite.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSprite.BackgroundImage")));
            this.btnSprite.Location = new System.Drawing.Point(332, 12);
            this.btnSprite.Name = "btnSprite";
            this.btnSprite.Size = new System.Drawing.Size(154, 107);
            this.btnSprite.TabIndex = 6;
            this.btnSprite.UseVisualStyleBackColor = true;
            this.btnSprite.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnSchweppes
            // 
            this.btnSchweppes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSchweppes.BackgroundImage")));
            this.btnSchweppes.Location = new System.Drawing.Point(492, 12);
            this.btnSchweppes.Name = "btnSchweppes";
            this.btnSchweppes.Size = new System.Drawing.Size(154, 107);
            this.btnSchweppes.TabIndex = 7;
            this.btnSchweppes.UseVisualStyleBackColor = true;
            this.btnSchweppes.Click += new System.EventHandler(this.btnSchweppes_Click);
            // 
            // btnRedBull
            // 
            this.btnRedBull.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRedBull.BackgroundImage")));
            this.btnRedBull.Location = new System.Drawing.Point(652, 12);
            this.btnRedBull.Name = "btnRedBull";
            this.btnRedBull.Size = new System.Drawing.Size(154, 107);
            this.btnRedBull.TabIndex = 8;
            this.btnRedBull.UseVisualStyleBackColor = true;
            this.btnRedBull.Click += new System.EventHandler(this.btnRedBull_Click);
            // 
            // button6
            // 
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.Location = new System.Drawing.Point(12, 125);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(154, 107);
            this.button6.TabIndex = 9;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.Location = new System.Drawing.Point(172, 125);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(154, 107);
            this.button7.TabIndex = 10;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.Location = new System.Drawing.Point(332, 125);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(154, 107);
            this.button8.TabIndex = 11;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.Location = new System.Drawing.Point(492, 125);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(154, 107);
            this.button9.TabIndex = 12;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button10.BackgroundImage")));
            this.button10.Location = new System.Drawing.Point(652, 125);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(154, 107);
            this.button10.TabIndex = 13;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button11.BackgroundImage")));
            this.button11.Location = new System.Drawing.Point(12, 238);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(154, 107);
            this.button11.TabIndex = 14;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnSmirnoff
            // 
            this.btnSmirnoff.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSmirnoff.BackgroundImage")));
            this.btnSmirnoff.Location = new System.Drawing.Point(172, 238);
            this.btnSmirnoff.Name = "btnSmirnoff";
            this.btnSmirnoff.Size = new System.Drawing.Size(154, 107);
            this.btnSmirnoff.TabIndex = 15;
            this.btnSmirnoff.UseVisualStyleBackColor = true;
            this.btnSmirnoff.Click += new System.EventHandler(this.btnSmirnoff_Click);
            // 
            // button13
            // 
            this.button13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button13.BackgroundImage")));
            this.button13.Location = new System.Drawing.Point(332, 238);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(154, 107);
            this.button13.TabIndex = 16;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button14.BackgroundImage")));
            this.button14.Location = new System.Drawing.Point(492, 238);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(154, 107);
            this.button14.TabIndex = 17;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button15.BackgroundImage")));
            this.button15.Location = new System.Drawing.Point(652, 238);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(154, 107);
            this.button15.TabIndex = 18;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // btnCalcMinus
            // 
            this.btnCalcMinus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcMinus.Location = new System.Drawing.Point(527, 397);
            this.btnCalcMinus.Name = "btnCalcMinus";
            this.btnCalcMinus.Size = new System.Drawing.Size(100, 100);
            this.btnCalcMinus.TabIndex = 28;
            this.btnCalcMinus.Text = "-";
            this.btnCalcMinus.UseVisualStyleBackColor = false;
            this.btnCalcMinus.Click += new System.EventHandler(this.btnCalcMinus_Click);
            // 
            // btnCalcPlus
            // 
            this.btnCalcPlus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnCalcPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcPlus.Location = new System.Drawing.Point(678, 397);
            this.btnCalcPlus.Name = "btnCalcPlus";
            this.btnCalcPlus.Size = new System.Drawing.Size(100, 100);
            this.btnCalcPlus.TabIndex = 30;
            this.btnCalcPlus.Text = "+";
            this.btnCalcPlus.UseVisualStyleBackColor = false;
            this.btnCalcPlus.Click += new System.EventHandler(this.btnCalcPlus_Click);
            // 
            // button16
            // 
            this.button16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button16.BackgroundImage")));
            this.button16.Location = new System.Drawing.Point(12, 351);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(154, 107);
            this.button16.TabIndex = 31;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button17.BackgroundImage")));
            this.button17.Location = new System.Drawing.Point(172, 351);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(154, 107);
            this.button17.TabIndex = 32;
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button18.BackgroundImage")));
            this.button18.Location = new System.Drawing.Point(332, 351);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(154, 107);
            this.button18.TabIndex = 33;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button19.BackgroundImage")));
            this.button19.Location = new System.Drawing.Point(12, 464);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(154, 107);
            this.button19.TabIndex = 34;
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button20.BackgroundImage")));
            this.button20.Location = new System.Drawing.Point(172, 464);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(154, 107);
            this.button20.TabIndex = 35;
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button21.BackgroundImage")));
            this.button21.Location = new System.Drawing.Point(332, 464);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(154, 107);
            this.button21.TabIndex = 36;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // btnFanta
            // 
            this.btnFanta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFanta.BackgroundImage")));
            this.btnFanta.Location = new System.Drawing.Point(172, 12);
            this.btnFanta.Name = "btnFanta";
            this.btnFanta.Size = new System.Drawing.Size(154, 107);
            this.btnFanta.TabIndex = 5;
            this.btnFanta.UseVisualStyleBackColor = true;
            this.btnFanta.Click += new System.EventHandler(this.btnFanta_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1133, 599);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.btnCalcPlus);
            this.Controls.Add(this.btnCalcMinus);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.btnSmirnoff);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.btnRedBull);
            this.Controls.Add(this.btnSchweppes);
            this.Controls.Add(this.btnSprite);
            this.Controls.Add(this.btnFanta);
            this.Controls.Add(this.btnCola);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCheckout);
            this.Controls.Add(this.orderlist);
            this.Name = "Form1";
            this.Text = "CashApp";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox orderlist;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnCola;
        private System.Windows.Forms.Button btnSprite;
        private System.Windows.Forms.Button btnSchweppes;
        private System.Windows.Forms.Button btnRedBull;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button btnSmirnoff;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button btnCalcMinus;
        private System.Windows.Forms.Button btnCalcPlus;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button btnFanta;
    }
}

